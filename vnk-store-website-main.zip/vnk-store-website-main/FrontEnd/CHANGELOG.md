# Changelog

## 3.7.0 (2023-05-06)

-   Upgrade to PrimeVue 3.28.0

**Implemented New Features and Enhancements**

## 3.6.0 (2023-04-12)

**Implemented New Features and Enhancements**

-   Upgrade to PrimeVue 3.26.1
-   Upgrade to vite 4.2.1
