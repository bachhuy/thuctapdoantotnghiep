package com.example.demo.entity;

public enum TokenType {
    ACCESS_TOKEN,
    REFRESH_TOKEN
}