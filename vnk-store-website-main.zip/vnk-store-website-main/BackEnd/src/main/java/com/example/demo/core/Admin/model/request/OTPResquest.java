package com.example.demo.core.Admin.model.request;

import lombok.Data;

@Data
public class OTPResquest {

    String ten;

    String email;

    String title;
}
