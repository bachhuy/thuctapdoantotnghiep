package com.example.demo.infrastructure.status;

public class KhuyenMaiStatus {
    public static final Integer DANG_HOAT_DONG = 0;
    public static final Integer HET_HAN = 1;
    public static final Integer CHUA_HOAT_DONG = 2;
    public static final Integer HET_KHUYEN_MAI = 3;
    public static final Integer DA_XOA = 4;
}
