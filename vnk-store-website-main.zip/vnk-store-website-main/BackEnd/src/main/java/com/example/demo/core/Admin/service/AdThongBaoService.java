package com.example.demo.core.Admin.service;

public interface AdThongBaoService {
}
