package com.example.demo.infrastructure.status;

public class ThongBaoStatus {
    public static final Integer DA_XEM = 0;
    public static final Integer CHUA_XEM = 1;
}
