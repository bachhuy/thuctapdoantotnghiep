package com.example.demo.infrastructure.status;

public class TrangThaiHoaDon {
    public static final Integer ONLINE = 1;
    public static final Integer  OFFLINE = 2;
}
