package com.example.demo.core.khachHang.repository;

import com.example.demo.reponsitory.ChiTietSanPhamReponsitory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KHChiTietSPRepository extends ChiTietSanPhamReponsitory {


}
