package com.example.demo.core.Admin.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChatUserResponse {
    private Integer id;
    private String ten;
    private String userName;
}
