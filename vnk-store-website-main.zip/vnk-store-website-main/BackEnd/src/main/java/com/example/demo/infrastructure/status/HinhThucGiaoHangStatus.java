package com.example.demo.infrastructure.status;

public class HinhThucGiaoHangStatus {

    public static final Integer TAIQUAY = 1;
    public static final Integer  GIAOHANG = 2;
}
