package com.example.demo.infrastructure;

import lombok.Data;

@Data

public class HDCTRespon {

    private String ma;

    private int soLuong;

    private String donGia;
}
