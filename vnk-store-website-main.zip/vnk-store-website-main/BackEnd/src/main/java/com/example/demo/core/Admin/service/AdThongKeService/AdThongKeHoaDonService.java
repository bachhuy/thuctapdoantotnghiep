package com.example.demo.core.Admin.service.AdThongKeService;

public interface AdThongKeHoaDonService {
    Integer tongDonhang();

    Integer tongDonhangHoanThanh();

    Integer tongDonhangDangGiao();

    Integer tongDonhangHuy();

    Integer tongDonhangHoanTra();


}
