package com.example.demo.entity;

public enum Role {
    NHANVIEN,
    USER,
    ADMIN
}
