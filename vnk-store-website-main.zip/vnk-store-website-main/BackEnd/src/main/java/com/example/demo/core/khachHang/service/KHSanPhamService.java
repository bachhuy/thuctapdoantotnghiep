package com.example.demo.core.khachHang.service;

import com.example.demo.core.khachHang.model.response.SanPhamResponse;

import java.util.List;

public interface KHSanPhamService {

    List<SanPhamResponse> getAll();
}
