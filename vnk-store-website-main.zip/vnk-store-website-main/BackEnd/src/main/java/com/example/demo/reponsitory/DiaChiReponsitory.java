package com.example.demo.reponsitory;

import com.example.demo.entity.DiaChi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DiaChiReponsitory extends JpaRepository<DiaChi, Integer> {
}
