package com.example.demo.util;

public class Const {
    public final static class SEND_MAIL_SUBJECT {
        public final static String CLIENT_REGISTER = "XÁC NHẬN TẠO MỚI THÔNG TIN NGƯỜI DÙNG";
    }

    public final static class TEMPLATE_FILE_NAME {
        public final static String CLIENT_REGISTER = "client";
    }

    public final static class SEND_MAIL_OTP {
        public final static String CLIENT_REGISTER = "XÁC NHẬN MÃ OTP";
    }

    public final static class TEMPLATE_OTP_NAME {
        public final static String CLIENT_REGISTER = "otp";
    }
}
