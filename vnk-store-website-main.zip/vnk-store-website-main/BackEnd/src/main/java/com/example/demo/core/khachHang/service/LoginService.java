package com.example.demo.core.khachHang.service;

import com.example.demo.core.khachHang.model.request.LoginPayLoad;

public interface LoginService {

    String login(LoginPayLoad loginPayload);

}
