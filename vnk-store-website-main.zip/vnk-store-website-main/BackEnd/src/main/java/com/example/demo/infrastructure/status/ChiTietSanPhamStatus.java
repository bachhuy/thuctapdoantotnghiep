package com.example.demo.infrastructure.status;

public class ChiTietSanPhamStatus {
    public static final Integer XOA = 0;
    public static final Integer CON_HANG = 1;
    public static final Integer HET_HANG = 2;
    public static final Integer TON_KHO = 3;

}
