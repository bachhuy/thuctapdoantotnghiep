package com.example.demo.entity;

public enum KieuGiamGia {
    GIAM_THEO_GIA,
    GIAM_THEO_PHAN_TRAM
}