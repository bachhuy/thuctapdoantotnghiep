package com.example.demo.infrastructure.status;

public class UserStatus {
    public static final Integer XOA = 0;
    public static final Integer TAI_KHOAN_BI_KHOA = 1;
    public static final Integer DANG_HOAT_DONG = 2;
}
