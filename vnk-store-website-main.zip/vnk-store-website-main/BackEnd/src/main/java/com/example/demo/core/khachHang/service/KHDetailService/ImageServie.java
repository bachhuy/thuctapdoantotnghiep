package com.example.demo.core.khachHang.service.KHDetailService;

import com.example.demo.entity.Image;

import java.util.List;

public interface ImageServie {

    List<Image> findByIdCTSP(Integer id);
}
