package com.example.demo.core.Admin.service.InterfaceHoaDon;

import com.example.demo.core.Admin.model.response.AdminHoaDonResponse;

public interface AdHoaDonDangGiaoService {

    AdminHoaDonResponse xacNhanHoaDon(Integer idHD);

}
