package com.example.demo.core.khachHang.model.response;

public interface KHDiaChiResponse {
}
