package com.example.demo.core.Admin.model.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BHTQPhuongThucThanhToanResponse {
    private Integer id;
    private String ten;
    private String ma;
    private String ngaySua;
    private String ngayTao;
    private Integer trangThai;
}
