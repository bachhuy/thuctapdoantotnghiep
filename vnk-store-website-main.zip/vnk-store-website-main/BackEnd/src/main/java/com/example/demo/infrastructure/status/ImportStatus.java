package com.example.demo.infrastructure.status;

public enum ImportStatus {
    SUCCESS,
    FAIL
}